import React from 'react'

export default function Nothing() {
  return (
    <div>Nothing Is Found</div>
  )
}
